﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Ch09ClassLib
{
   public class MyExternalClass
   {
   }
}
