Readme.txt

Here should be some information about the MDI Editor and the installation!

Known problems with this version, requirements for installation, where to report bugs, etc.